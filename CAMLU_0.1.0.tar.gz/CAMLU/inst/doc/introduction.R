## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval = FALSE------------------------------------------------------
#  install.packages("devtools")
#  library(devtools)
#  
#  install_github("ziyili20/CAMLU", build_vignettes = TRUE)
#  library(CAMLU)

## ----run1, eval = FALSE, message = FALSE--------------------------------------
#  ## Load data
#  library(CAMLU)
#  data(PBMC_tumor_simulation_data)
#  
#  ## Distinguish novel cells from known cell types
#  label_01 <- CAMLU(x_train = simdata$fdata_train,
#                    x_test = simdata$fdata_test,
#                    ngene=5000,lognormalize=TRUE)
#  
#  ## Display the classification table
#  truelabel <- simdata$labels_2
#  print(table(label_01, truelabel))

## ----plot, eval = FALSE, message = TRUE---------------------------------------
#  library(SingleCellExperiment)
#  library(scater)
#  sce <- SingleCellExperiment(list(counts=simdata$fdata_test),
#                              colData=DataFrame(celltype=as.factor(truelabel),
#                                                predicted = as.factor(label_01))
#                              )
#  sce <- logNormCounts(sce) ## add log normalized counts
#  sce <- runTSNE(sce, perplexity=10)
#  par(mfrow = c(1,2))
#  plotTSNE(sce, colour_by = "celltype")
#  plotTSNE(sce, colour_by = "predicted")
#  

## ----run2, message=TRUE, eval = FALSE-----------------------------------------
#  ## Enable full annotation function: assign the full spectrum of labels
#  label_all <- CAMLU(x_train = simdata$fdata_train,
#                    x_test = simdata$fdata_test,
#                    y_train = simdata$labels_train,
#                    full_annotation = TRUE,
#                    ngene=3000,
#                    lognormalize=TRUE)
#  
#  ## Display the classification table
#  truelabel_all <- simdata$labels_test
#  truelabel_all[truelabel_all == "HNCC"] <- "Unknown"
#  table(label_all$label_full, truelabel_all)
#  
#  ## Calculate the accuracy
#  sum(label_all$label_full == truelabel_all)/ length(truelabel_all)

## ----plot2, eval = FALSE, message = TRUE--------------------------------------
#  sce <- SingleCellExperiment(list(counts=simdata$fdata_test),
#                              colData=DataFrame(celltype=as.factor(simdata$labels_test),
#                                                predicted = as.factor(label_all$label_full))
#  )
#  sce <- logNormCounts(sce) ## add log normalized counts
#  sce <- runTSNE(sce, perplexity=10)
#  par(mfrow = c(1,2))
#  plotTSNE(sce, colour_by = "celltype")
#  plotTSNE(sce, colour_by = "predicted")
#  

